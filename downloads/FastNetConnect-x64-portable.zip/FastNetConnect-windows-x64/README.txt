FastNet Connect for Windows
===========================

Use your iPhone's cellular data on this PC, through the ProxyDeck app on the
iPhone.

Start
-----
1. Keep FastNetConnect.exe and wintun.dll together in the same folder.
2. Double-click FastNetConnect.exe. Windows asks for administrator approval:
   the app needs it to create its network adapter.
3. On the iPhone, turn on Personal Hotspot. On this PC, join that Wi-Fi network.
4. In FastNet Connect, click Connect. A pairing code (QR) appears.
5. On the iPhone, open ProxyDeck and scan the code. Keep ProxyDeck open and
   on screen while you use the PC.

When the window says "Connected through your iPhone", everything on this PC
goes out over the iPhone's cellular data.

Good to know
------------
- If the iPhone locks or ProxyDeck goes to the background, the PC falls back
  to its normal network until ProxyDeck is open again.
- Closing the window disconnects and removes the FastNet network adapter.
- Free trial: 2 hours of connected time. After that, a one-time license
  unlocks the app: click "Activate in FastNet Connect" on the page you get
  after buying, or paste the key (Enter license key, bottom right).
- Not working? Click Diagnose (bottom right). It checks each part of the
  connection and says which one fails; Copy report gives support the details.
- Log file, if support asks for it:
  %LocalAppData%\FastNet\connect.log

wintun.dll is the WireGuard project's TUN driver (https://www.wintun.net/),
distributed under the license in wintun-LICENSE.txt.
